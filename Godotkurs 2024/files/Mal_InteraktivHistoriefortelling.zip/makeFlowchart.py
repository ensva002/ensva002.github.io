import os, re

scene_connections = {}
all_scenes = set()
referenced_scenes = set()

def extract_main_scene(file_path):
    target_scene_name = None
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            content = file.read()
            match = re.search(r'run/main_scene="([^"]+)"', content)
            if match:
                scene_path = match.group(1)
                scene_name_with_extension = os.path.basename(scene_path)
                target_scene_name = os.path.splitext(scene_name_with_extension)[0]
    return target_scene_name


def extract_connections(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        matches = re.findall(r'scene_path\s*=\s*"([^"]+)"', content)
        scene_basename = os.path.basename(file_path)
        all_scenes.add(scene_basename)
        if matches:
            referenced_scene_basenames = [os.path.basename(match) for match in matches]
            scene_connections[scene_basename] = referenced_scene_basenames
            referenced_scenes.update(referenced_scene_basenames)

def traverse_directory(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".tscn"):
                file_path = os.path.join(root, file)
                extract_connections(file_path)

def generate_flowchart():
    flowchart = "# "+os.path.basename(os.getcwd())+"\n```mermaid\nflowchart\n"
    flowchart += "    classDef missing stroke:#d94a3f,stroke-dasharray: 5 5;\n"
    flowchart += "    classDef isolated stroke:#d9a441;\n"
    flowchart += "    classDef start stroke:#00aa33;\n"

    for scene, connections in scene_connections.items():
        scene_name = os.path.splitext(scene)[0]
        for connection in connections:
            connection_name = os.path.splitext(connection)[0]
            flowchart += f'    {scene_name} --> {connection_name}\n'

    isolated_scenes = all_scenes - set(scene_connections.keys()) - set(sum(scene_connections.values(), []))
    non_existent_referenced_scenes = referenced_scenes - all_scenes

    isolated_nodes = []
    non_existent_nodes = []

    for scene in isolated_scenes:
        scene_name = os.path.splitext(scene)[0]
        flowchart += f'    {scene_name}\n'
        isolated_nodes.append(scene_name)
    
    for scene in non_existent_referenced_scenes:
        scene_name = os.path.splitext(scene)[0]
        flowchart += f'    {scene_name}\n'
        non_existent_nodes.append(scene_name)
    
    if isolated_nodes:
        isolated_nodes_str = ','.join(isolated_nodes)
        flowchart += f"    class {isolated_nodes_str} isolated\n"
    if non_existent_nodes:
        non_existent_nodes_str = ','.join(non_existent_nodes)
        flowchart += f"    class {non_existent_nodes_str} missing\n"
    mainScene = extract_main_scene("project.godot")
    flowchart += "    class "+mainScene+" start\n```\n---"
    return flowchart


def main():
    traverse_directory(".")
    flowchart = generate_flowchart()
    with open("scene_flowchart.md", "w") as f:
        f.write(flowchart)

if __name__ == "__main__":
    main()
